package com.zdatainc.rts.storm;

public class Wekacaller {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WekaTutorial Weka1 = new WekaTutorial();
		//Weka1.We
		Weka1.executeDuplicate();
	}

}
