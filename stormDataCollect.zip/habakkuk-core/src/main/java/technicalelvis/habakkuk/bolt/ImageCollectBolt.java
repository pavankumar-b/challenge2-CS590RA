
package technicalelvis.habakkuk.bolt;

import org.apache.log4j.Logger;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.Random;

import backtype.storm.topology.BasicOutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBasicBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;

public class ImageCollectBolt extends BaseBasicBolt
{
    private static final long serialVersionUID = 42L;
/*    private static final Logger LOGGER =
        Logger.getLogger(PrinterBolt.class);*/
    private static final ObjectMapper mapper = new ObjectMapper();
    
    File file = new File("/home/cloudera/Twitter.txt");
    File file2 = new File("/home/cloudera/Image.txt");

    FileWriter fw = null;
     BufferedWriter bw = null;
     
     FileWriter fw2 = null;
     BufferedWriter bw2 = null;
    
     long id;
     String text = null;
     
    public void declareOutputFields(OutputFieldsDeclarer declarer)
    {
    	   declarer.declare(new Fields("result"));
    }

    public void execute(Tuple input, BasicOutputCollector collector)
    {
    	
    	
    	 try {

    	    	if(!file.exists())
    	    	{
    	    		file.createNewFile();
    	    	}
     		
     		fw = new FileWriter(file.getAbsoluteFile(),true);
     		 bw = new BufferedWriter(fw);
     		 bw.write("\n"+input);

     	    	bw.close();
     	        
     	} catch (IOException e) {
     		// TODO Auto-generated catch block
     		e.printStackTrace();
     	}
    	
				collector.emit(new Values("xxx"));
    	 
    	 
    }

    public Map<String, Object> getComponenetConfiguration() { return null; }
}


